/* Class holds any type of database record as a collections
   of fields which are strings. If -ea is used, run the
   unit tests */

import java.util.*;

class Record {
  private List<String> Record = new ArrayList<String>();

  int getNumFields() {
    return Record.size();
  }

  void addField(String field) {
    Record.add(field);
  }

  String getField(int index) {
    return Record.get(index);
  }

  void setField(int index, String field) {
    Record.set(index, field);
  }

  boolean containsField(String field) {
    return Record.contains(field);
  }

  // If -ea is used, run unit tests
  public static void main(String[] args) {
    boolean testing = false;
    assert(testing = true);
    Record program = new Record();
    if (testing) program.test();
    else {
        System.err.println("Use:");
        System.err.println("  java -ea Record     for testing");
        System.exit(1);
    }
  }

  // Calls unit tests
  private void test() {
    testGetNumFields();
    Record.clear();
    testAddField();
    Record.clear();
    testGetFields();
    Record.clear();
    testSetField();
    Record.clear();
    testContainsField();
  }

  private void testGetNumFields() {
    assert(getNumFields() == 0);
    Record.add("dog");
    assert(getNumFields() == 1);
  }

  private void testAddField() {
    assert(getNumFields() == 0);
    addField("cat");
    assert(Record.get(0).equals("cat"));
    addField("mouse");
    assert(Record.get(1).equals("mouse"));
  }

  private void testGetFields() {
    addField("nike");
    assert(getField(0).equals("nike"));
    addField("adidas");
    assert(getField(1).equals("adidas"));
  }

  private void testSetField() {
    addField("disney");
    assert(getField(0).equals("disney"));
    setField(0, "pixar");
    assert(getField(0).equals("pixar"));
  }

  private void testContainsField() {
    addField("churchill");
    assert(containsField("churchill") == true);
    addField("blair");
    assert(containsField("blair") == true);
    assert(containsField("cameron") == false);
  }
}
