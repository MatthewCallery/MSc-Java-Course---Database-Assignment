/* Prints out a table, ensuring the columns line up */

import java.io.*;
import java.util.*;

class Display {
  private int maxColumnWidth = 12;
  private String rowDiv = "------------";

  // Ensure column width is large enough for all fields in the table
  void setColumnWidth(int columnSize){
    String newRowDiv = "";
    if(columnSize > (maxColumnWidth - 3)){
      maxColumnWidth = columnSize + 3;
      for(int i = 0; i < maxColumnWidth; i++){
        newRowDiv = newRowDiv + "-";
      }
      rowDiv = newRowDiv;
    }
  }

  // Prints out a formatted table with columns lined up
  void printTable(String tableData) {
    String[] lines = tableData.split("\n");

    System.out.format("\n-%s%s%s\n", rowDiv, rowDiv, rowDiv);
    for(int i = 0; i < lines.length; i++){
      String[] words = lines[i].split(",");
      for(int j = 0; j < words.length; j++){
        System.out.format("%-" + maxColumnWidth + "s", words[j]);
      }
      System.out.println();
      if(i == 0){
        System.out.format("-%s%s%s\n", rowDiv, rowDiv, rowDiv);
      }
    }
    System.out.format("-%s%s%s\n\n", rowDiv, rowDiv, rowDiv);
  }

  // If -ea is used, run unit tests
  public static void main(String[] args) {
    boolean testing = false;
    assert(testing = true);
    Display program = new Display();
    if (testing) program.test();
    else {
        System.err.println("Use:");
        System.err.println("  java -ea Display     for testing");
        System.exit(1);
    }
  }

  // Calls unit tests
  private void test() {
    testSetColumnWidth();
  }

  // Check maxColumnWidth being set correctly
  private void testSetColumnWidth() {
    setColumnWidth(7);
    assert(maxColumnWidth == 12);
    setColumnWidth(9);
    assert(maxColumnWidth == 12);
    setColumnWidth(10);
    assert(maxColumnWidth == 13);
    setColumnWidth(15);
    assert(maxColumnWidth == 18);
  }
}
