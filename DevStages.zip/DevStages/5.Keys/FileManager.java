/* Manages reading data from, and writing back to, files */

import java.util.*;
import java.io.*;

class FileManager {

  // Reads data from specified file and returns as list of strings
  List<String> scanFile(String fileName) {
    List<String> lines = new ArrayList<String>();

    try{
      File file = new File(fileName);
      Scanner in = new Scanner(file);
      while(in.hasNextLine()){
        lines.add(in.nextLine());
      }
      in.close();
    } catch (Exception e) { throw new Error(e); }

    return lines;
  }

  // Writes string of data to specified file
  void saveFile(String fileName, String tableContent){
    try{
      Writer fileWriter = new FileWriter(fileName, false);
      fileWriter.write(tableContent);
      fileWriter.flush();
      fileWriter.close();
    } catch (Exception e) { throw new Error(e); }
  }
}
