/* Class currently used to test communication between
   FileManager class and Table class */

import java.util.*;

class DB {
  private FileManager fileManager = new FileManager();
  private Table table = new Table();
  private Display display = new Display();

  public static void main(String[] args) {
    DB program = new DB();
    program.run();
  }

  private void run() {
    List<String> lines = new ArrayList<String>();
    lines = fileManager.scanFile("test.txt");
    table.createFromFile(lines);
    display.setColumnWidth(table.getMaxColumnWidth());
    display.setNumColumns(table.getNumColumns());
    display.printTable(table.outputTable());
    //table.deleteColumn("age");
    fileManager.saveFile("test.txt", table.outputTable());
  }
}
