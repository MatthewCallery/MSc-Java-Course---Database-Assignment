import java.util.*;

class Table {
  private List<Record> Table = new ArrayList<Record>();
  private List<String> columnList = new ArrayList<String>();
  private int numColumns = 0;

  int getNumRecords() {
    return Table.size();
  }

  void insertRecord(String row) {
    Record newRecord = new Record();
    String[] words = row.split(" ");

    for(int i = 0; i < words.length; i++){
      newRecord.addField(words[i]);
    }
    Table.add(newRecord);
  }

  void deleteRecord(int rowIndex) {
    Table.remove(rowIndex);
  }

  /* Removes from Table all of the Records whose index is between
  fromIndex(inclusive) and toIndex(inclusive) */
  void deleteRecordRange(int fromIndex, int toIndex) {
    for(int i = toIndex; i >= fromIndex; i--){
      Table.remove(i);
    }
  }

  Record selectRecord(int rowIndex) {
    return Table.get(rowIndex);
  }

  void setColumnNames(String names) {
    String[] words = names.split(" ");

    this.numColumns = words.length;

    for(int i = 0; i < numColumns; i++){
      columnList.add(words[i]);
    }
  }

  void deleteColumn(String columnName) {
    int columnIndex = columnList.indexOf(columnName);
    int numRows = getNumRecords();

    columnList.remove(columnIndex);

    for(int i = 0; i < numRows; i++){
      Record temp = Table.get(i);
      temp.deleteField(columnIndex);
      deleteRecord(i);
      Table.add(i, temp);
    }
    numColumns -= 1;
  }

  public static void main(String[] args) {
    boolean testing = false;
    assert(testing = true);
    Table program = new Table();
    if (testing) program.test();
    else {
        System.err.println("Use:");
        System.err.println("  java -ea Table     for testing");
        System.exit(1);
    }
  }

  private void test() {
    testGetNumRecords();
    Table.clear();
    testInsertRecord();
    Table.clear();
    testDeleteRecord();
    Table.clear();
    testDeleteRecordRange();
    Table.clear();
    testSetColumnNames();
    columnList.clear();
    Table.clear();
    testDeleteColumn();
  }

  private void testGetNumRecords() {
    assert(getNumRecords() == 0);
    insertRecord("dog");
    assert(getNumRecords() == 1);
  }

  private void testInsertRecord() {
    assert(getNumRecords() == 0);
    insertRecord("beckham");
    assert(getNumRecords() == 1);
    insertRecord("rooney");
    assert(getNumRecords() == 2);
  }

  private void testDeleteRecord() {
    assert(getNumRecords() == 0);
    insertRecord("badger");
    insertRecord("ferret");
    deleteRecord(1);
    assert(getNumRecords() == 1);
    deleteRecord(0);
    assert(getNumRecords() == 0);
  }

  private void testDeleteRecordRange() {
    assert(getNumRecords() == 0);
    insertRecord("badger");
    insertRecord("ferret");
    insertRecord("minx");
    deleteRecordRange(0, 1);
    assert(getNumRecords() == 1);
  }

  private void testSetColumnNames() {
    setColumnNames("fname lname age height weight");
    assert(numColumns == 5);
    assert(columnList.get(0).equals("fname"));
    assert(columnList.get(4).equals("weight"));
  }

  private void testDeleteColumn() {
    setColumnNames("fname lname age height weight");
    insertRecord("Matthew Callery 25 187 82");
    assert(numColumns == 5);
    assert(columnList.get(2).equals("age"));
    deleteColumn("age");
    assert(numColumns == 4);
    assert(columnList.get(2).equals("height"));
  }
}
