/* Class currently used to test communication between
   FileManager class and Table class */

import java.util.*;

class DB {
  private FileManager fileManager = new FileManager();
  private Table table = new Table();

  public static void main(String[] args) {
    DB program = new DB();
    program.run();
  }

  private void run() {
    List<String> lines = new ArrayList<String>();
    lines = fileManager.scanFile("test.txt");
    table.setColumnNames(lines.get(0));
    for(int i = 1; i < lines.size(); i++){
      table.insertRecord(lines.get(i));
    }
    table.deleteColumn("age");
    fileManager.saveFile("test.txt", table.outputTable());
  }
}
