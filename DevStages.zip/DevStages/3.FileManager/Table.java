/* Class stores a collection of rdatabase ecords as well as field
   names. If -ea is used, run the unit tests */

import java.util.*;

class Table {
  private List<Record> Table = new ArrayList<Record>();
  List<String> columnList = new ArrayList<String>();
  private int numColumns = 0;

  int getNumRecords() {
    return Table.size();
  }

  // Overloaded method. First inserts at 'bottom' of table
  void insertRecord(String row) {
    Table.add(createRecord(row));
  }

  // Inserts at specified position index
  void insertRecord(String row, int index) {
    Table.add(index, createRecord(row));
  }

  // Returns new record from a string of fields separated by commas
  private Record createRecord(String row) {
    Record newRecord = new Record();
    String[] words = row.split(",");

    for(int i = 0; i < words.length; i++){
      newRecord.addField(words[i]);
    }
    return newRecord;
  }

  void deleteRecord(int rowIndex) {
    Table.remove(rowIndex);
  }

  /* Removes from Table all of the Records whose index is between
  fromIndex(inclusive) and toIndex(inclusive) */
  void deleteRecordRange(int fromIndex, int toIndex) {
    for(int i = toIndex; i >= fromIndex; i--){
      Table.remove(i);
    }
  }

  Record selectRecord(int rowIndex) {
    return Table.get(rowIndex);
  }

  // Creates table (with 0 records) from string of column names
  void setColumnNames(String names) {
    String[] words = names.split(",");

    this.numColumns = words.length;

    for(int i = 0; i < numColumns; i++){
      columnList.add(words[i]);
    }
  }

  void deleteColumn(String columnName) {
    int columnIndex = columnList.indexOf(columnName);
    int numRows = getNumRecords();

    columnList.remove(columnIndex);

    for(int i = 0; i < numRows; i++){
      Record temp = Table.get(i);
      temp.deleteField(columnIndex);
      deleteRecord(i);
      Table.add(i, temp);
    }
    numColumns -= 1;
  }

  // Returns string containing table data for writing to file
  String outputTable() {
    String data = "";
    data = outputColumnList(data);
    data = outputRecords(data);
    return data;
  }

  // Appends data from list of column names to string 'data'
  private String outputColumnList(String data) {
    for(int i = 0; i < numColumns; i++){
      data += columnList.get(i);
      data += ",";
    }
    data = data.substring(0, data.length() - 1);
    data += "\n";
    return data;
  }

  // Appends data from records to string 'data'
  private String outputRecords(String data) {
    for(int x = 0; x < getNumRecords(); x++){
      Record temp = Table.get(x);
      for(int y = 0; y < temp.getNumFields(); y++){
        data += temp.getField(y);
        data += ",";
      }
      data = data.substring(0, data.length() - 1);
      data += "\n";
    }
    return data;
  }

  // If -ea is used, run unit tests
  public static void main(String[] args) {
    boolean testing = false;
    assert(testing = true);
    Table program = new Table();
    if (testing) program.test();
    else {
        System.err.println("Use:");
        System.err.println("  java -ea Table     for testing");
        System.exit(1);
    }
  }

  // Calls unit tests
  private void test() {
    testGetNumRecords();
    Table.clear();
    testInsertRecord();
    Table.clear();
    testDeleteRecord();
    Table.clear();
    testDeleteRecordRange();
    Table.clear();
    testSetColumnNames();
    columnList.clear();
    Table.clear();
    testDeleteColumn();
    columnList.clear();
    Table.clear();
    testOutputColumnList();
    columnList.clear();
    Table.clear();
    testOutputRecords();
  }

  // test return of number of rows in table
  private void testGetNumRecords() {
    assert(getNumRecords() == 0);
    insertRecord("dog");
    assert(getNumRecords() == 1);
  }

  // test overloaded method to insert record
  private void testInsertRecord() {
    assert(getNumRecords() == 0);
    insertRecord("beckham");
    assert(getNumRecords() == 1);
    insertRecord("rooney");
    assert(getNumRecords() == 2);
    insertRecord("cole", 0);
    assert(Table.get(0).getField(0).equals("cole"));
    assert(Table.get(1).getField(0).equals("beckham"));
  }

  // test row is successfully deleted from table
  private void testDeleteRecord() {
    assert(getNumRecords() == 0);
    insertRecord("badger");
    insertRecord("ferret");
    deleteRecord(1);
    assert(getNumRecords() == 1);
    deleteRecord(0);
    assert(getNumRecords() == 0);
  }

  // test range of records are successfully deleted from table
  private void testDeleteRecordRange() {
    assert(getNumRecords() == 0);
    insertRecord("badger");
    insertRecord("ferret");
    insertRecord("minx");
    deleteRecordRange(0, 1);
    assert(getNumRecords() == 1);
  }

  // test table is successfully created with passed column names
  private void testSetColumnNames() {
    setColumnNames("fname,lname,age,height,weight");
    assert(numColumns == 5);
    assert(columnList.get(0).equals("fname"));
    assert(columnList.get(4).equals("weight"));
  }

  // test column successfully deleted from table
  private void testDeleteColumn() {
    setColumnNames("fname,lname,age,height,weight");
    insertRecord("Matthew,Callery,25,187,82");
    assert(numColumns == 5);
    assert(columnList.get(2).equals("age"));
    deleteColumn("age");
    assert(numColumns == 4);
    assert(columnList.get(2).equals("height"));
  }

  // test column name data is output in correct format for writing to file
  private void testOutputColumnList() {
    setColumnNames("fname,lname,age,height,weight");
    assert(outputColumnList("").equals("fname,lname,age,height,weight\n"));
  }

  // test record data is output in correct format for writing to file
  private void testOutputRecords(){
    insertRecord("matthew,callery,25");
    insertRecord("owen,farrell,26");
    assert(outputRecords("").equals("matthew,callery,25\nowen,farrell,26\n"));
  }
}
